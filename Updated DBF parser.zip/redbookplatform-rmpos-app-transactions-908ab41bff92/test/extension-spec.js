var assert = require('chai').assert;
var ext    = require('../lib/local-plugins');
var tools  = require('agent-testing-tools')();

describe('Local Plugins', function() {

    it('should load', function () {
        assert.ok(ext, 'no extension available');
    });

    describe('Metadata', function () {

        it('should have a name', function () {
            assert.ok(ext.name, 0, 'has no depth');
            assert.isString(ext.version)
        });

        it('should have a version', function () {
            assert.ok(ext.version);
            assert.isString(ext.version)
        });
        it('should have an attach point', function () {
            assert.ok(ext.attach, 'is not idle');
            assert.isFunction(ext.attach)
        });
    });

    describe('Contents', function () {

        var err, plugins;

        before(function(done){
            tools.loadExtension(ext, {}, function(_err, _plugins) {
                err = _err;
                plugins = _plugins;
                done();
            })
        });

        it('should not produce an error', function () {
            assert.isFalse(!!err);
        });

        it('should load the plugins', function () {
            assert.ok(plugins);
        });

    });


    describe('Transfer', function () {

        var err, plugins;

        before(function(done){
            tools.loadExtension(ext, {}, function(_err, _plugins) {
                err = _err;
                plugins = _plugins;
                console.log(plugins);
                done();
            })
        });


        it('should contain the context', function () {
            console.log(plugins.local);
            assert.isOk(plugins.local.transfer);
            assert.isObject(plugins.local.transfer);
        });


        it('should contain createUrl', function () {
            assert.isOk(plugins.local.transfer.createUrl);
            assert.isFunction(plugins.local.transfer.createUrl);
        });

        it('should contain serializeContent', function () {
            assert.isOk(plugins.local.transfer.serializeContent);
            assert.isFunction(plugins.local.transfer.serializeContent);
        });

        it('should contain uploadContent', function () {
            assert.isOk(plugins.local.transfer.uploadContent);
            assert.isFunction(plugins.local.transfer.uploadContent);
        });

    });

    describe('File', function () {

        var err, plugins;

        before(function(done){
            tools.loadExtension(ext, {}, function(_err, _plugins) {
                err = _err;
                plugins = _plugins;
                console.log(plugins);
                done();
            })
        });


        it('should contain the context', function () {
            console.log(plugins.local);
            assert.isOk(plugins.local.file);
            assert.isObject(plugins.local.file);
        });

        it('should contain load', function () {
            assert.isOk(plugins.local.file.load);
            assert.isFunction(plugins.local.file.load);
        });

        it('should contain parse', function () {
            assert.isOk(plugins.local.file.parse);
            assert.isFunction(plugins.local.file.parse);
        });

        it('should contain save', function () {
            assert.isOk(plugins.local.file.save);
            assert.isFunction(plugins.local.file.save);
        });

    });

});
