#!/bin/sh

npmrc artifactory
npm   publish ./dist
npmrc default
