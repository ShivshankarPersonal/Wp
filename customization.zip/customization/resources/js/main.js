$(document).on('ready', function () {
    $('#carousel-oneStopShop').carousel({
        interval: false
    });

});