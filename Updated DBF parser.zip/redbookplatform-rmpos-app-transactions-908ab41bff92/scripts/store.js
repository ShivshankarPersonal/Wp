var fs = require('fs');
xml2js = require('xml2js');

var parser = new xml2js.Parser({
    explicitArray: false,
    trim: true,
    normalizeTags: true
});

fs.readFile('./data/iboi_export_20110316_20160414-011341.xml', 'utf-8', function(err, data){
    parser.parseString(data, function (err, result) {
        console.dir(result.export.storeinfo);
    });
});
