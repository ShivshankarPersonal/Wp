var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var salesTransaction = module.exports = {};

/**
 * Schema for SalesTransaction Collection
 */
var salesTransactionSchema = new Schema({

    store_id:String,
    timestamp:Date,
    business_day:String,
    order_id:String,
    order_number:Number,
    order_opened_at:Date,
    order_closed_at:Date,
    canceled_closed:Boolean,
    voided_closed:Boolean,
    training:Boolean,
    employee:String,
    service_type:String,
    delivery_type:String,
    department:String,
    revenue_center:String,
    customer:String,
    table:String,
    type:String,
    point_of_sale_brand:String,
    point_of_sale:String,
    external_id:String,
    guest_count:Number,
    car_count:Number,
    modified:Boolean,
    currency_code:String,
    currency_scale:String,
    gross_total:Number,
    tax_total:Number,
    discount_total:Number,
    net_total:Number,
    tax_details:[],
    discount_details:[],
    tender_total:Number,
    gratuity_total:Number,
    change_total:Number,
    tender_details:[],
    change_details:[],
    tax_id:String,
    tax_exempt:Boolean,
    tax_index:Number,
    auto_tendered:Boolean,
    discounted:Number,
    item_count:Boolean
});
var SalesTransaction = mongoose.model('SalesTransaction', salesTransactionSchema);
salesTransaction.insert = function (req, res) {
    //insert after 20sec (20000 milliseconds) on arrival of dataset insert request
    setTimeout(saveRec, 2000);

    function saveRec() {
        //We can apply logic on input data and we can post to cloud, example is below
        var store_id = 'hotSchedule-' + req.body.a;
        var timestamp = req.body.b;
        var business_day = req.body.c;
        var order_id = req.body.d;
        var order_number = req.body.e;
        var order_opened_at = req.body.f;
        var salesTransaction = new SalesTransaction({
            store_id: store_id, timestamp: timestamp, business_day: business_day,
            order_id: order_id, order_number: order_number, order_opened_at: order_opened_at
        });
        salesTransaction.save(function (err) {
            res.send();
            if (err) {
                console.log("failed" + err);
            } else {
                console.log("inserted record");
            }
        });
    }
};


/**
 * Schema for SalesItem Collection
 */
var salesItemSchema = new mongoose.Schema({
    store__id:String,
    timestamp:Date,
    business_day:String,
    order_id:String,
    order_number:Number,
    tansaction_id:String,
    line_number:Number,
    description:String,
    sales_category:String,
    department:String,
    type:String,
    canceled_closed:Boolean,
    voided_closed:Boolean,
    non_sales_item:Boolean,
    discounted:Boolean,
    modified:Boolean,
    quantity:Number,
    currency_scale:Number,
    currency_code:String,
    unit_price:Number,
    gross_total:Number,
    tax_total:Number,
    discount_total:Number,
    net_total:Number,
    tax_details:[],
    discount_details:Number,
    tax_index:Number,
    tax_id:Number,
    tax_exempt:Boolean,
    external_ids:[]
});

var SalesItem = mongoose.model("SalesItem", salesItemSchema);

/**
 * Schema for SalesAmount Collection
 */
var salesAmountSchema = new mongoose.Schema({
    rate : Number,
    amount : Number,
    id : String,
    category : String,
    index : Number
});

var SalesAmount = mongoose.model("SalesAmount", salesAmountSchema);

/**
 * Insert documents into SalesAmount Collection
 */
salesTransaction.insertIntoSalesAmount = function(req, res){

    insert();

    /**
     * Create model instance and save into the collection
     */
    function insert(){
        var salesAmount = new SalesAmount({
            rate : req.body.rate,
            amount : req.body.amount,
            id : req.body.id,
            category : req.body.category,
            index : req.body.index
        });
        salesAmount.save(function(err){
            if(err){
                console.log(err);
            }else{
                console.log("Successfully saved");
            }

        });
    }
    req.send();
};

/**
 * Schema for TimeCard Collection
 */
var timeCardSchema = new mongoose.Schema({
    store__id:String,
    business_day:String,
    employee_id:String,
    job_id:String,
    employee_reference:String,
    store_reference:String,
    job_reference:String,
    external_ids:[],
    regular_rate:Number,
    overtime_rate:Number,
    double_rate:Number,
    started_at:Date,
    ended_at:Date
});

var TimeCard = mongoose.model("TimeCard", timeCardSchema);