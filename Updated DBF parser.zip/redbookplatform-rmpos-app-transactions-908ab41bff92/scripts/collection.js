var fs = require('fs');
xml2js = require('xml2js');

var parser = new xml2js.Parser({
    explicitArray: false,
    trim: true,
    normalizeTags: true
});

var coll = (process.argv[2]);

fs.readFile('/Users/brian/dev/node/projects/xpient-app-transactions/data/iboi_export_20110316_20160414-011341.xml', 'utf-8', function(err, data){
    parser.parseString(data, function (err, result) {

        if(!coll) {
            for (key in result.export) {
                console.dir(key);
            }
            return;
        }

        console.log('')


        //employees             = employees
        //jobcodes              = jobcodes
        //destinations          = rev centers
        //menuitemcategories    = sales item



        var col = result.export[coll];

        if(!col) {
            console.log('no such key %s', coll)
        } else {
            keys = Object.getOwnPropertyNames(col);
            console.log('>>', keys[0]);
            var key = keys[0];
            if (!keys || !keys.length) {
                console.log('no sub key');
                process.exit(0)
            }
            var hash = {};
            col[key].forEach(function (key) {
                hash[key.id] = key;
            });
            console.log(hash);
        }
    });
});
