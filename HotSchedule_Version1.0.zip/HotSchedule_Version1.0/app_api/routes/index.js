var express = require('express');
var router = express.Router();
var combineValidColumns = require("../models/combineValidColumns");
var salesTransaction = require("../models/salesTransaction");

router.get('/combine', combineValidColumns.combine);
//uncomment later
//router.post('/insertIntoSalesAmount',salesTransaction.insertIntoSalesAmount);


module.exports = router;
