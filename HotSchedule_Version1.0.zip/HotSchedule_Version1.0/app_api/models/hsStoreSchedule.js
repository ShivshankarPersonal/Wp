var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var HSStoreSchedule = module.exports = {};

/**
 * HSStoreSchedule Schema and Collection
 */
 var hSStoreScheduleSchema = new Schema({
    store_id : String,
    employee : String,
    job : String,
    external : String,
    start_at : String,
    stop_at : String
});

var HSStoreSchedule = mongoose.model("HSStoreSchedule", hSStoreScheduleSchema);