var path = require('path');
var pkg  = require('./package.json')

module.exports = {

    name       : pkg.name        || 'default-app-name',
    version    : pkg.version     || '0.0.0',
    description: pkg.description || 'application description',
    publisher  : 'HotSchedules',

    /* --Parameters { Objects }
        settings that can be declared externally per deployment
        they will be referenced internally as settings
     */
    parameters: {},

    /* --Settings: [ Array of Objects ]
        Static Configuration Data
     */
    settings: [],

    /* --Extensions [Array of Objects]
        An extension loads a set plugins that can be used in the application
        from either an application specific source or a external library
     */
    extensions: [],

    /* --Service
        A service defines injectable behavior or state that can be used/shared
        across components.
     */
    services: [
        {name: 'cloud', provider: 'connection:resources'}
    ],

    /* --Counters
        Basic Metrics Counters for Events
     */
    counters: {},

    /* --Sources
     A source defines an external event source observed by the application.
     */
    sources: [],

    /* --Pipelines
     A pipeline is a set of functions that process a message/data a sequence of discrete steps
     */
    pipelines: [
        {name: 'MyPipeline', subscriptions: ['ready', 'startup'],
            steps: [
                {
                    fn: function (input, next) {
                        try {
                            var self = this;
                            console.log(this);
                            var client = self.conn.getSuperagent();
                            console.log('uploading a new structure to ', self.conn);
                            client.post('resources/MyStructure', {
                                store_id: 'secret-store',
                                key_a: 332
                            }, function (err, json, res) {
                                console.log(err, json, res);
                                next(err, json);
                            })
                        } catch (err){
                            console.log('err', err);
                            next(err);
                        }
                    }, props: {
                      conn: '$service:cloud'
                    }
                },
            ]
        }
    ],

    /*
     Handlers (might be better renamed as actors)
     A Handler subscribes to specific events and processes the messages
     */
    handlers: [],

    /**
     * Init
     * A Routine to run prior to activating sources
     */
    init: function (initialized) {
        var app = this;
        console.log(app.plugins.clone())
        console.log(app.services)
        initialized && initialized();
    }
};
