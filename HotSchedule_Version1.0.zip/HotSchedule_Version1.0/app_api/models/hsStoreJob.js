var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var hssStoreJob = module.exports = {};


/**
 * HSSStoreJob Schema and Collection
 */
var hsStoreJobSchema = new Schema({
    instore_id : String,
    instore_name : String,
    store_id : String,
    regular_rate : Number,
    overtime_rate : Number,
    double_rate : Number

});

var HSStoreJob = mongoose.model("HSStoreJob", hsStoreJobSchema);


/**
 * HSStoreEmployee Schema and Collection
 */

var hsStoreEmployeeSchema = new Schema({
    name : String,
    nickname : String,
    birthdate : String,
    address : String,
    email : String,
    status : String,
    employement_period : String,
    instore_id : String,
    hr_id : String,
    store : String,
    store_id : String,
    phone_numbers : String
});

var HSStoreEmployee = mongoose.model("HSStoreEmployee", hsStoreEmployeeSchema);


/**
 * HSStoreemployeeJob Schema and Collection
 */
 var hSStoreemployeeJobSchema = new Schema({
    store_id : String,
    employee_id : String,
    job_id : String,
    store : String,
    employee : String,
    job : String,
    regular_rate : Number,
    overtime_rate : Number,
    doubletime_rate : Number,
    external_ids : String
});

var HSStoreemployeeJob = mongoose.model("HSStoreemployeeJob", hSStoreemployeeJobSchema);


/**
 * HSRevenueCenter Schema and Collection
 */
var hSRevenueCenterSchema = new Schema({
    store_id : String,
    instore_id : String
    instore_name : String,
    display_name : String
});

var HSRevenueCenter = mongoose.model("HSRevenueCenter", hSRevenueCenterSchema);

/**
 * HSSalesCategory Schema and Collection
 */
var hSSalesCategorySchema = new Schema({
    store_id : String,
    instore_id : String
    instore_name : String,
    display_name : String
});

var HSSalesCategory = mongoose.model("HSSalesCategory", hSSalesCategorySchema);


/**
 * HSSalesDay Schema and Collection
 */
var hSSalesDaySchema = new Schema({
    store_id : String,
    business_day : String,
    total : Number,
    count: Number,
    items : [Number],
    store : String
});

var HSSalesDay = mongoose.model("HSSalesDay", hSSalesDaySchema);

/**
 * HSSalesItem Schema and Collection
 */
 var hSSalesItemSchema = new Schema({
    store_id : String,
    business_day : String,
    transaction_date_time : Date,
    amount : Number,
    revenue_center : String,
    sales_category : String,
    employee : String,
    store : String,
    order_id : String,
    transaction_id : String,
    external_ids : [String,Number]

});

var HSSalesItem = mongoose.model("HSSalesItem", hSSalesItemSchema);


/**
 * HSVolumeDay Schema and Collection
 */
var hSVolumeDaySchema = new Schema({
    store_id : String,
    business_day : String,
    total : Number,
    count : Number,
    items : [Number],
    store : String,
    volume_type : String
});

var HSVolumeDay = mongoose.model("HSVolumeDay", hSVolumeDaySchema);


/**
 * HSVolumeItem Schema and Collection
 */
 var hSVolumeItemSchema = new Schema({
    store_id : String,
    business_day : String,
    transaction_date_time : Date,
    amount : Number,
    revenue_center : String,
    sales_category : String,
    employee : String,
    store : String,
    order_id : String,
    transaction_id : String,
    external_ids : [String,Number],
    volume_type : String

});

var HSVolumeItem = mongoose.model("HSVolumeItem", hSVolumeItemSchema);


/**
 * HSTimeCard Schema and Collection
 */
var hSTimeCardSchema = new Schema({
    store_id : String,
    job_id : String,
    employee_id : String,
    employee_reference : String,
    job_reference : String,
    store_reference : String,
    business_day : String,
    started_at : Date,
    ended_at : Date,
    regular_rate : Number,
    overtime_rate : Number,
    doubletime_rate : Number,
    external_ids : [String,Number]
});

var HSTimeCard = mongoose.model("HSTimeCard", hSTimeCardSchema);

