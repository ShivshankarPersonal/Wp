var path = require('path');
var pkg  = require('./package.json');
const fs = require('fs');


module.exports = {

    name       : pkg.name        || 'rmpos-app-name',
    version    : pkg.version     || '0.0.0',
    description: pkg.description || 'application description',
    publisher  : 'ITCInfoTech',

    /* --Settings: [ Array of Objects ]
     Static Configuration Data
     */
    settings: [
        //{property  : 'date_dir' , value: 'D:/Projects/IoT Platform/test-app/file.txt'}
    ],

    /* --Extensions [Array of Objects]
     An extension loads a set plugins that can be used in the application
     from either an application specific source or a external library
     */
    extensions: [
        {module: 'agent-ext-fs'},
        {module: 'agent-ext-common'},
        {module: 'agent-ext-dbfkit'},
        {module: './lib/local-plugins'}
    ],

    /* --Service
     A service defines injectable behavior or state that can be used/shared
     across components.
     */
    services: [
        {
            name    : 'cloud',
            provider: 'connection:resources'
        },
    ],

    /* --Counters
     Basic Metrics Counters for Events
     */
    counters: {
        activations : ['ready'],
        ignored     : ['file:ignored'],
        processed   : ['file:processed']
    },

    /* --Sources
     A source defines an external event source observed by the application.
     */
    sources: [
    ],

    /* --Pipelines
     A pipeline is a set of functions that process a message/data a sequence of discrete steps
     */
    pipelines: [
        {
            name: 'AdaptFromSource',
            subscriptions: ['ready'],
            steps: [
                {fn: function(input, next){
                    console.log('... Upload Starting ...');
                    next(null, input)
                } },
                {fn:'$plugins:fs:io:load',
                    props: {
                        path: '../data/REV.dbf'
                    }
                },
                {fn:'$plugins:fs:checksum:file'},
                //{fn:'$plugins:local:file:ifCommitted',
                //    props: {
                //        storage    : '$services:localStorage'
                //    }
                //},
                {fn:'$plugins:fs:io:read'},
                {fn:'$plugins:dbf:parse:buffer', props: {
                    options: {
                        sequenced: false,
                        deleted  : false
                    }
                }},
                {fn: '$plugins:core:identity:add'},
                {fn: "$plugins:local:transfer:createUrl" },
                {fn: "$plugins:local:transfer:serializeContent"},
                {fn: "$plugins:fs:zip:content", props: {as: 'rev.json'}},
                {fn: "$plugins:local:transfer:uploadContent" , props: {
                    conn   : '$service:cloud'
                }},
                {fn: '$plugins:local:file:commit',
                    props: {
                        storage    : '$services:localStorage'
                    }
                },
                {fn: '$plugins:fs:io:save',
                    props: {as: 'uploaded.zip'}
                },
                {fn:function(input, next){
                    console.log('processed %s', input.path);
                    next(null, input);
                }},
            ],
            success : 'file:processed',
            stopped : 'file:ignored',
            failure : 'error:saving'
        }
    ],

    /*
     Handlers (might be better renamed as actors)
     A Handler subscribes to specific events and processes the messages
     */
    handlers: [

    ],

    /**
     * Init
     * A Routine to run prior to activating sources
     */
    init: function (initialized) {
        var app = this;
        console.log('%s started watching %s', app.name, app.settings.clone().data_dir);
        app.logger.info('---- %s started watching %s -----', app.name, app.settings.clone().data_dir);
        initialized && initialized();
    }
};
