# Agent Application: Compris POS


## Getting Started
To use agent applications, you must first install the global tools

* hs-toolbox
* hs-agent-tools

### Developer Setup

````
$  git clone git@bitbucket.org:redbookplatform/xpient-app-transactions.git
$  setup.bat
````

## Project Structure

## Git Project Structure

````
/<install_dir>
 |-/data                        # Sample Data Files
 |-/lib                         # Local Application Components
    |-/handlers                 # Local Handlers       (optional)
    |-/middlewares              # Local Middleware     (optional)
    |-/services                 # Local Services       (optional)
    |-/sources                  # Local Services       (optional)
    |-/util                     # Local Services       (optional)
    |-local-plugins.js          # Local Extenstion     (optional)
 |-/settings                    # Declarative Settings (optional)
 |-/scripts                     # Helpful ShellJS Scripts
    |-setup.js                  # setup the expected project structure 
    |-reset.js                  # clear logs and storage 
 |-/test                        # mocha test files
    |-*.js                      # test files
 |-.gitignore.js                # files to ignore for version control purposes
 |-Grunt.js                     # project workflow scripts
 |-index.js                     # application file
 |-package.json                 # node manifest file
````

## Local Structure

__[+]__ denotes a directory managed by GIT
__[-]__ denotes a local unmanaged directory

````
/<install_dir>
 |-/agent               [-]     # Local Agent
 |-/data                [+]     # Sample Data Files
 |-/input               [-]     # Local Input Folder                       
 |-/node_modules        [-]     # External Dependencies
 |-/lib                 [+]     # Local Application Components
 |-/settings            [+]     # Declarative Settings (optional)
 |-scripts              [+]     # Project ShellJS Scripts
 |-test                 [+]     # automated tests
 |-.gitignore.js        [+]     # files to ignore for version control purposes
 |-Grunt.js             [+]     # project workflow scripts
 |-index.js             [+]     # application file
 |-package.json         [+]     # node manifest file
 |-README.md            [+]     # readme file
````

##Configuration
````

###Local

//../agent.json

apps: [
  {
	name: "xpient-transactions",
	module: "../",
	enabled: true,
	settings: [
	    { property: "data_dir", value: "../input" }
	]
  }
]

###Standard

// agent.json
apps: [
  {
	name: "Xpient Transactions",
	module: "xpient-app-transactions",
	enabled: true,
	settings: [
	    { property: "data_dir", value: "path/to/Compris/XML/output" }
	]
  }
]

````

### Settings
* *property*: to be set as "data_directory"
* *value*: Needs to be SET to the directory where your data input is stored

***

##Dependencies

Extensions used by this application

* agent-ext-fs
* agent-ext-shell
* agent-ext-common

##Generalized Data Flow

````
 [Source] Check the Archive Directory ==> [file:found: VFile]

     1. Read the File
     2. Check the Signature
     3. 
 
 AdaptToSource <Pipeline>
 
    1. Parse XML
    2. Clean up JSON
    3.    

````

# License
Copyright (c) 2016 HotSchedules Inc

Licensed under the Apache2 license.
